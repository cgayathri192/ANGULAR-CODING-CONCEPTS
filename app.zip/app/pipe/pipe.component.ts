import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.scss']
})
export class PipeComponent implements OnInit {
name = "gayathri";
name1 = "GAYATHRI";
DOB = new Date();
salary = 40000;
person1 = {
  name:'gayathri',
  age:21,
  salary:34000
}
num = 0.99;
name2 = "gayathri";
date='2023/11/06';


  constructor() { }

  ngOnInit(): void {
  }

}
