import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.scss']
})
export class SecondComponent implements OnInit {
@Input()primary:any;
@Input()secondary:any;
@Output() result = new EventEmitter();
test1 = 20;
test2 = 30;
  constructor() { }

  ngOnInit(): void {
    console.log(this.primary,this.secondary);
  }
  sub(){
    let res = this.primary-this.secondary;
    this.result.emit(res);
  }
  mul(){
    let res = 20+30;
    console.log(res);
  }

}
