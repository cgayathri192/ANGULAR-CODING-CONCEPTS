import { Component, OnInit, ViewChild } from '@angular/core';
import { TwoComponent } from '../two/two.component';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.scss']
})
export class OneComponent implements OnInit {
firstvalue = 20;
secondvalue = 30;
result:any;
@ViewChild(TwoComponent) private TwoComponent!:TwoComponent
  constructor() { }
  showParentResult(res:any){
    this.result = res;
    console.log(this.result)
  }
  ngOnInit(): void {
  }
  ngAfterViewInit(){
    this.test();
  }
  test(){
    this.TwoComponent.sub();
  }
}
