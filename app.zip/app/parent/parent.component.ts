import { Component, OnInit, ViewChild } from '@angular/core';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {
firstvalue = 30;
secondvalue = 50;
result:any;
@ViewChild(ChildComponent) private ChildComponent!:ChildComponent
  constructor() { }
  ShowParentResult(res:any){
    this.result = res;
    console.log(this.result)
  }

  ngOnInit(): void {
  }
  ngAfterViewInit(){
    this.test();
  }
  test(){
    this.ChildComponent.sub()
  }

}
