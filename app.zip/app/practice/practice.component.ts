import { Component, OnInit } from '@angular/core';
import { PracticeService } from '../practice.service';

@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.scss']
})
export class PracticeComponent implements OnInit {
x:any;
  constructor(private ser:PracticeService) { }

  ngOnInit(): void {
  }
  getdata() {
    this.ser.get().subscribe((d=>{
      console.log(d)
  }))
  }

}
