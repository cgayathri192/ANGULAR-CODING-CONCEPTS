import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-style',
  templateUrl: './style.component.html',
  styleUrls: ['./style.component.scss']
})
export class StyleComponent implements OnInit {
cvar:string="blue";
mystyle:object={
  color:'pink',
  background:'grey',
  border:'5px solid blue'
}
hasError:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }

}
